export type NonceResponse = {
  nonce: string
  messageToSign: string
}
